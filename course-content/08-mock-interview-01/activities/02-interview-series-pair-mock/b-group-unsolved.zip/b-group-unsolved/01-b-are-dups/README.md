# INTERVIEW QUESTIONS

## Are-Dups

## Instructions
Given an array, return true if there is at least one duplicate element in the array. If not, return false

## Example
Test Case 1: [1,2,13,12,4,2]
Expected Output: true

Test Case 2:[1,2,3,4]
Expected Output: false

## Optimal Time
O(n)