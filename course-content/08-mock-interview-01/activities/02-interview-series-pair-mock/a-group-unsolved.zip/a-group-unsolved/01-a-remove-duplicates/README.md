# INTERVIEW QUESTIONS

## Remove Duplicates

## Instructions
Given an array of integers, return an array of non-duplicate / unique elements. 

## Example
Test Case 1: [1,3,3,3,1,5]
Expected Output: [1,3,5]

Test Case 2:[]
Expected Output: []

Test Case 3:[1,1,1,1]
Expected Output:[1]

## Optimal Time
O(n)