# INTERVIEW QUESTIONS

## Common characters between strings

## Instructions
Given two strings S1 and S2, return a string/char array consisting of characters that are common between S1 and S2. It should not have repeated characters.

## Example
Test Case 1: 'aabbaa', 'abc'
Expected Output: 'ab'

Test Case 2:'','abc'
Expected Output: ''

## Optimal Time
O(n)