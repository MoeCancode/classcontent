# INTERVIEW QUESTIONS

## Reverse a string

## Instructions
Given string S, reverse it.

## Example
Test Case 1: 'apple'
Expected Output: 'elppa'

Test Case 2:''
Expected Output: ''

## Optimal Time
O(n)

## Bonus
Reverse the given in place i.e without creating a new string.