# INTERVIEW QUESTIONS

## Compress String

## Instructions
Given string S, return a string that represents a compressed version of S.

## Example
Test Case 1: 'AAAaaaCB'
Expected Output: 'A3a3C1B1'

Test Case 2:''
Expected Output: ' 0'

Test Case 3:'AAAABBBBCCCCCDDEEEE'
Expected Output:'A4B4C5D2E4'

## Optimal Time
O(n)